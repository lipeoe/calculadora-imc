# calculadora-imc
Aplicativo para calcular o índice de massa corporal
